<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="world-1-1" tilewidth="48" tileheight="48" tilecount="870" columns="29">
 <image source="world-1-1.png" width="1392" height="1440"/>
</tileset>
