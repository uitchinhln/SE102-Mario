<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Tileset" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="870" columns="29">
 <image source="1.png" trans="ff80c0" width="498" height="516"/>
</tileset>
