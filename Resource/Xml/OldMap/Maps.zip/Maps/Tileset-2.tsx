<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="3" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="1533" columns="73">
 <image source="3.png" trans="ff80c0" width="1242" height="358"/>
</tileset>
